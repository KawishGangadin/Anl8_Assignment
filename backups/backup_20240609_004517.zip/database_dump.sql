BEGIN TRANSACTION;
CREATE TABLE members (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            age INTEGER CHECK(age >= 0),
            gender TEXT CHECK(gender IN ('Male', 'Female', 'Other')),
            weight REAL CHECK(weight >= 0),
            address TEXT,
            email TEXT UNIQUE NOT NULL,
            mobile TEXT UNIQUE NOT NULL,
            registration_date DATE NOT NULL,
            membership_id TEXT UNIQUE NOT NULL
        );
INSERT INTO "members" VALUES(2,'Testaccount','Testaccount',14,'Female',67.0,'van Heusdestraat 99','test@gmail.com','62809017','2024-06-08','2424196020');
CREATE TABLE users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL,
            registration_date DATE NOT NULL,
            role TEXT CHECK(role IN ('admin', 'consultant', 'superadmin')) NOT NULL,
            temp BOOLEAN NOT NULL CHECK(temp IN (0, 1))
        );
INSERT INTO "users" VALUES(1,'Kawish','Gangadin','super_admin','Admin_123?','2024-06-07','superadmin',0);
INSERT INTO "users" VALUES(5,'Noah','Bismilla','bin_noah1911','AHHH!23hhhHH33HH','2024-06-08','consultant',1);
INSERT INTO "users" VALUES(6,'nowa','bin el minyari','a123456','Tampppp_123!','2024-06-08','admin',1);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('users',6);
INSERT INTO "sqlite_sequence" VALUES('members',3);
COMMIT;
