class Authorization:
    pass